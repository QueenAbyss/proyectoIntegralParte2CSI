"use client"

import type React from "react"

import { useRef, useEffect, useState, useCallback } from "react"

interface DraggablePoint {
  id: string
  x: number
  y: number
  screenX: number
  screenY: number
  isDragging: boolean
  color: string
  size: number
  label: string
}

interface DraggableCanvasProps {
  width: number
  height: number
  functions: Record<string, (x: number) => number>
  currentFunction: string
  partitions: number
  leftLimit: number
  rightLimit: number
  approximationType: "left" | "right" | "middle"
  showArea: boolean
  onLimitChange: (left: number, right: number) => void
  onFunctionPointDrag?: (x: number, y: number) => void
  mode: "guided" | "free"
  tutorialStep: number
}

export function DraggableCanvas({
  width,
  height,
  functions,
  currentFunction,
  partitions,
  leftLimit,
  rightLimit,
  approximationType,
  showArea,
  onLimitChange,
  onFunctionPointDrag,
  mode,
  tutorialStep,
}: DraggableCanvasProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const [draggablePoints, setDraggablePoints] = useState<DraggablePoint[]>([])
  const [isDragging, setIsDragging] = useState(false)
  const [dragTarget, setDragTarget] = useState<string | null>(null)
  const [mousePos, setMousePos] = useState({ x: 0, y: 0 })

  // Initialize draggable points
  useEffect(() => {
    const points: DraggablePoint[] = [
      {
        id: "leftLimit",
        x: leftLimit,
        y: 0,
        screenX: 100 + ((leftLimit - leftLimit) / (rightLimit - leftLimit)) * (width - 200),
        screenY: height - 100,
        isDragging: false,
        color: "#FF6B6B",
        size: 12,
        label: "a",
      },
      {
        id: "rightLimit",
        x: rightLimit,
        y: 0,
        screenX: 100 + ((rightLimit - leftLimit) / (rightLimit - leftLimit)) * (width - 200),
        screenY: height - 100,
        isDragging: false,
        color: "#4ECDC4",
        size: 12,
        label: "b",
      },
    ]

    // Add function control points for free mode
    if (mode === "free") {
      const func = functions[currentFunction]
      const numControlPoints = 5
      for (let i = 0; i <= numControlPoints; i++) {
        const x = leftLimit + (i / numControlPoints) * (rightLimit - leftLimit)
        const y = func(x)
        points.push({
          id: `control_${i}`,
          x,
          y,
          screenX: 100 + ((x - leftLimit) / (rightLimit - leftLimit)) * (width - 200),
          screenY: height - 100 - y * 40,
          isDragging: false,
          color: "#9B59B6",
          size: 8,
          label: `P${i}`,
        })
      }
    }

    setDraggablePoints(points)
  }, [leftLimit, rightLimit, currentFunction, mode, width, height, functions])

  // Convert screen coordinates to mathematical coordinates
  const screenToMath = useCallback(
    (screenX: number, screenY: number) => {
      const mathX = leftLimit + ((screenX - 100) / (width - 200)) * (rightLimit - leftLimit)
      const mathY = (height - 100 - screenY) / 40
      return { x: mathX, y: mathY }
    },
    [leftLimit, rightLimit, width, height],
  )

  // Convert mathematical coordinates to screen coordinates
  const mathToScreen = useCallback(
    (mathX: number, mathY: number) => {
      const screenX = 100 + ((mathX - leftLimit) / (rightLimit - leftLimit)) * (width - 200)
      const screenY = height - 100 - mathY * 40
      return { x: screenX, y: screenY }
    },
    [leftLimit, rightLimit, width, height],
  )

  // Check if point is near mouse
  const isPointNearMouse = (point: DraggablePoint, mouseX: number, mouseY: number) => {
    const distance = Math.sqrt((point.screenX - mouseX) ** 2 + (point.screenY - mouseY) ** 2)
    return distance <= point.size + 5
  }

  // Mouse event handlers
  const handleMouseDown = (event: React.MouseEvent<HTMLCanvasElement>) => {
    if (mode === "guided" && tutorialStep !== 5) return

    const canvas = canvasRef.current
    if (!canvas) return

    const rect = canvas.getBoundingClientRect()
    const mouseX = event.clientX - rect.left
    const mouseY = event.clientY - rect.top

    // Check if clicking on any draggable point
    for (const point of draggablePoints) {
      if (isPointNearMouse(point, mouseX, mouseY)) {
        setIsDragging(true)
        setDragTarget(point.id)
        setMousePos({ x: mouseX, y: mouseY })

        // Update point dragging state
        setDraggablePoints((prev) => prev.map((p) => ({ ...p, isDragging: p.id === point.id })))
        break
      }
    }
  }

  const handleMouseMove = (event: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current
    if (!canvas) return

    const rect = canvas.getBoundingClientRect()
    const mouseX = event.clientX - rect.left
    const mouseY = event.clientY - rect.top

    setMousePos({ x: mouseX, y: mouseY })

    if (isDragging && dragTarget) {
      const mathCoords = screenToMath(mouseX, mouseY)

      setDraggablePoints((prev) =>
        prev.map((point) => {
          if (point.id === dragTarget) {
            let newX = mathCoords.x
            let newY = mathCoords.y

            // Constrain limit points
            if (point.id === "leftLimit") {
              newX = Math.max(-5, Math.min(-0.1, newX))
              newY = 0
              onLimitChange(newX, rightLimit)
            } else if (point.id === "rightLimit") {
              newX = Math.max(0.1, Math.min(6, newX))
              newY = 0
              onLimitChange(leftLimit, newX)
            } else if (point.id.startsWith("control_")) {
              // Constrain control points to reasonable bounds
              newY = Math.max(0, Math.min(8, newY))
              if (onFunctionPointDrag) {
                onFunctionPointDrag(newX, newY)
              }
            }

            const screenCoords = mathToScreen(newX, newY)
            return {
              ...point,
              x: newX,
              y: newY,
              screenX: screenCoords.x,
              screenY: screenCoords.y,
            }
          }
          return point
        }),
      )
    }

    // Update cursor style
    const canvas_element = canvas
    let isOverDraggable = false
    for (const point of draggablePoints) {
      if (isPointNearMouse(point, mouseX, mouseY)) {
        isOverDraggable = true
        break
      }
    }
    canvas_element.style.cursor = isOverDraggable ? "grab" : "default"
    if (isDragging) {
      canvas_element.style.cursor = "grabbing"
    }
  }

  const handleMouseUp = () => {
    setIsDragging(false)
    setDragTarget(null)
    setDraggablePoints((prev) => prev.map((p) => ({ ...p, isDragging: false })))
  }

  // Drawing function
  const drawGarden = useCallback(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    // Clear canvas with garden background
    const gradient = ctx.createLinearGradient(0, 0, 0, height)
    gradient.addColorStop(0, "#87CEEB") // Sky blue
    gradient.addColorStop(0.7, "#98FB98") // Pale green
    gradient.addColorStop(1, "#228B22") // Forest green
    ctx.fillStyle = gradient
    ctx.fillRect(0, 0, width, height)

    // Draw coordinate system as stone path
    ctx.strokeStyle = "#8B7355"
    ctx.lineWidth = 3

    // X-axis (horizontal stone path)
    ctx.beginPath()
    ctx.moveTo(50, height - 100)
    ctx.lineTo(width - 50, height - 100)
    ctx.stroke()

    // Y-axis (vertical stone path)
    ctx.beginPath()
    ctx.moveTo(100, 50)
    ctx.lineTo(100, height - 50)
    ctx.stroke()

    // Draw grid lines
    ctx.strokeStyle = "rgba(139, 115, 85, 0.3)"
    ctx.lineWidth = 1

    // Vertical grid lines
    for (let i = 1; i < 10; i++) {
      const x = 100 + (i / 10) * (width - 200)
      ctx.beginPath()
      ctx.moveTo(x, 50)
      ctx.lineTo(x, height - 50)
      ctx.stroke()
    }

    // Horizontal grid lines
    for (let i = 1; i < 8; i++) {
      const y = 50 + (i / 8) * (height - 150)
      ctx.beginPath()
      ctx.moveTo(100, y)
      ctx.lineTo(width - 50, y)
      ctx.stroke()
    }

    // Draw function curve as magical fence
    const func = functions[currentFunction]
    const a = leftLimit
    const b = rightLimit

    ctx.strokeStyle = "#8A2BE2"
    ctx.lineWidth = 4
    ctx.beginPath()

    for (let x = a; x <= b; x += 0.1) {
      const screenX = 100 + ((x - a) / (b - a)) * (width - 200)
      const screenY = height - 100 - func(x) * 40

      if (x === a) {
        ctx.moveTo(screenX, screenY)
      } else {
        ctx.lineTo(screenX, screenY)
      }
    }
    ctx.stroke()

    // Draw Riemann rectangles as flower pots
    if (showArea) {
      const n = partitions
      const dx = (b - a) / n

      for (let i = 0; i < n; i++) {
        let x: number
        switch (approximationType) {
          case "left":
            x = a + i * dx
            break
          case "right":
            x = a + (i + 1) * dx
            break
          case "middle":
            x = a + (i + 0.5) * dx
            break
        }

        const height_rect = func(x)
        const screenX = 100 + ((a + i * dx - a) / (b - a)) * (width - 200)
        const screenY = height - 100
        const rectWidth = (dx / (b - a)) * (width - 200)
        const rectHeight = height_rect * 40

        const hue = 120 + (i * 360) / n
        const saturation = 70 + Math.sin(i * 0.5) * 20 // Varying saturation for visual interest
        const lightness = 60 + (height_rect / 8) * 20 // Lightness based on function value

        // Draw flower pot (trapezoid shape) with enhanced styling
        ctx.fillStyle = `hsl(${hue}, ${saturation}%, ${lightness}%)`
        ctx.beginPath()
        ctx.moveTo(screenX, screenY)
        ctx.lineTo(screenX + rectWidth, screenY)
        ctx.lineTo(screenX + rectWidth * 0.8, screenY - rectHeight)
        ctx.lineTo(screenX + rectWidth * 0.2, screenY - rectHeight)
        ctx.closePath()
        ctx.fill()

        // Add border to show individual rectangles clearly
        ctx.strokeStyle = "rgba(255, 255, 255, 0.8)"
        ctx.lineWidth = 1
        ctx.stroke()

        // Draw flower on top with size proportional to function value
        const flowerSize = 6 + (height_rect / 8) * 4
        ctx.fillStyle = `hsl(${hue + 60}, 80%, 70%)`
        ctx.beginPath()
        ctx.arc(screenX + rectWidth / 2, screenY - rectHeight - 10, flowerSize, 0, 2 * Math.PI)
        ctx.fill()

        // Add sparkles for magical effect with density based on accuracy
        if (mode === "free") {
          const sparkleCount = Math.max(1, Math.floor(partitions / 10))
          ctx.fillStyle = "#FFD700"
          for (let j = 0; j < sparkleCount; j++) {
            const sparkleX = screenX + Math.random() * rectWidth
            const sparkleY = screenY - Math.random() * rectHeight
            const sparkleSize = 1 + Math.random() * 2
            ctx.beginPath()
            ctx.arc(sparkleX, sparkleY, sparkleSize, 0, 2 * Math.PI)
            ctx.fill()
          }
        }

        if (approximationType === "left") {
          ctx.fillStyle = "rgba(255, 0, 0, 0.6)"
          ctx.beginPath()
          ctx.arc(screenX + 3, screenY - rectHeight + 3, 2, 0, 2 * Math.PI)
          ctx.fill()
        } else if (approximationType === "right") {
          ctx.fillStyle = "rgba(0, 0, 255, 0.6)"
          ctx.beginPath()
          ctx.arc(screenX + rectWidth - 3, screenY - rectHeight + 3, 2, 0, 2 * Math.PI)
          ctx.fill()
        } else if (approximationType === "middle") {
          ctx.fillStyle = "rgba(0, 255, 0, 0.6)"
          ctx.beginPath()
          ctx.arc(screenX + rectWidth / 2, screenY - rectHeight + 3, 2, 0, 2 * Math.PI)
          ctx.fill()
        }
      }

      // Show additivity by highlighting middle division
      if (n >= 4) {
        const midPoint = Math.floor(n / 2)
        const midScreenX = 100 + ((a + midPoint * dx - a) / (b - a)) * (width - 200)

        ctx.strokeStyle = "rgba(255, 215, 0, 0.8)"
        ctx.lineWidth = 3
        ctx.setLineDash([10, 5])
        ctx.beginPath()
        ctx.moveTo(midScreenX, screenY)
        ctx.lineTo(midScreenX, 50)
        ctx.stroke()
        ctx.setLineDash([])

        // Add labels for additivity
        ctx.fillStyle = "rgba(255, 215, 0, 0.9)"
        ctx.font = "12px Arial"
        ctx.fillText("∫[a,c]", 110, screenY - 10)
        ctx.fillText("∫[c,b]", midScreenX + 10, screenY - 10)
      }
    }

    // Draw draggable points
    draggablePoints.forEach((point) => {
      // Draw point shadow
      ctx.fillStyle = "rgba(0, 0, 0, 0.3)"
      ctx.beginPath()
      ctx.arc(point.screenX + 2, point.screenY + 2, point.size, 0, 2 * Math.PI)
      ctx.fill()

      // Draw point
      ctx.fillStyle = point.isDragging ? "#FFD700" : point.color
      ctx.strokeStyle = "#FFFFFF"
      ctx.lineWidth = 2
      ctx.beginPath()
      ctx.arc(point.screenX, point.screenY, point.size, 0, 2 * Math.PI)
      ctx.fill()
      ctx.stroke()

      // Draw point label
      ctx.fillStyle = "#333333"
      ctx.font = "12px Arial"
      ctx.textAlign = "center"
      ctx.fillText(point.label, point.screenX, point.screenY - point.size - 5)

      // Draw connection lines for limit points
      if (point.id === "leftLimit" || point.id === "rightLimit") {
        ctx.strokeStyle = point.color
        ctx.lineWidth = 2
        ctx.setLineDash([5, 5])
        ctx.beginPath()
        ctx.moveTo(point.screenX, point.screenY)
        ctx.lineTo(point.screenX, 50)
        ctx.stroke()
        ctx.setLineDash([])
      }
    })

    // Draw fairy if in guided mode
    if (mode === "guided" && tutorialStep > 0) {
      ctx.fillStyle = "#FFD700"
      ctx.beginPath()
      ctx.arc(50, 50, 15, 0, 2 * Math.PI)
      ctx.fill()

      // Fairy wings
      ctx.fillStyle = "rgba(255, 255, 255, 0.7)"
      ctx.beginPath()
      ctx.ellipse(40, 45, 8, 12, -0.3, 0, 2 * Math.PI)
      ctx.ellipse(60, 45, 8, 12, 0.3, 0, 2 * Math.PI)
      ctx.fill()
    }

    // Draw hover effects
    if (mode === "free") {
      draggablePoints.forEach((point) => {
        if (isPointNearMouse(point, mousePos.x, mousePos.y) && !isDragging) {
          ctx.strokeStyle = "#FFD700"
          ctx.lineWidth = 3
          ctx.beginPath()
          ctx.arc(point.screenX, point.screenY, point.size + 5, 0, 2 * Math.PI)
          ctx.stroke()
        }
      })
    }
  }, [
    width,
    height,
    functions,
    currentFunction,
    leftLimit,
    rightLimit,
    partitions,
    approximationType,
    showArea,
    draggablePoints,
    mode,
    tutorialStep,
    mousePos,
    isDragging,
  ])

  // Animation loop
  useEffect(() => {
    const animate = () => {
      drawGarden()
      requestAnimationFrame(animate)
    }
    animate()
  }, [drawGarden])

  return (
    <div className="relative">
      <canvas
        ref={canvasRef}
        width={width}
        height={height}
        className="w-full border-2 border-green-300 rounded-lg cursor-default function-curve rectangles"
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onMouseLeave={handleMouseUp}
      />
      <div
        className="absolute inset-0 pointer-events-none function-curve-overlay"
        style={{ top: "20%", height: "30%" }}
      />
      <div className="absolute inset-0 pointer-events-none rectangles-overlay" style={{ top: "50%", height: "40%" }} />
    </div>
  )
}
