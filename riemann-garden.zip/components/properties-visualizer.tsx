"use client"

import { useState, useRef, useEffect } from "react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Play, Pause, RotateCcw, Sparkles } from "lucide-react"

interface PropertiesVisualizerProps {
  functions: Record<string, (x: number) => number>
  currentFunction: string
  leftLimit: number
  rightLimit: number
  partitions: number
}

export function PropertiesVisualizer({
  functions,
  currentFunction,
  leftLimit,
  rightLimit,
  partitions,
}: PropertiesVisualizerProps) {
  const [activeProperty, setActiveProperty] = useState("linearity")
  const [isAnimating, setIsAnimating] = useState(false)
  const [animationStep, setAnimationStep] = useState(0)
  const [showTheory, setShowTheory] = useState(false)
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const animationRef = useRef<number>()

  // Animation control
  useEffect(() => {
    if (isAnimating) {
      const animate = () => {
        setAnimationStep((prev) => (prev + 1) % 120) // 2 second cycle at 60fps
        animationRef.current = requestAnimationFrame(animate)
      }
      animationRef.current = requestAnimationFrame(animate)
    } else {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current)
      }
    }

    return () => {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current)
      }
    }
  }, [isAnimating])

  // Drawing functions for each property
  const drawLinearity = () => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    const width = canvas.width
    const height = canvas.height

    // Clear with magical background
    const gradient = ctx.createLinearGradient(0, 0, 0, height)
    gradient.addColorStop(0, "#E8F4FD")
    gradient.addColorStop(1, "#B3E5FC")
    ctx.fillStyle = gradient
    ctx.fillRect(0, 0, width, height)

    // Draw coordinate system
    ctx.strokeStyle = "#666"
    ctx.lineWidth = 2
    ctx.beginPath()
    ctx.moveTo(50, height - 50)
    ctx.lineTo(width - 50, height - 50)
    ctx.moveTo(50, 50)
    ctx.lineTo(50, height - 50)
    ctx.stroke()

    const func = functions[currentFunction]
    const a = leftLimit
    const b = rightLimit

    // Draw original function
    ctx.strokeStyle = "#2196F3"
    ctx.lineWidth = 3
    ctx.beginPath()
    for (let x = a; x <= b; x += 0.1) {
      const screenX = 50 + ((x - a) / (b - a)) * (width - 100)
      const screenY = height - 50 - func(x) * 30
      if (x === a) {
        ctx.moveTo(screenX, screenY)
      } else {
        ctx.lineTo(screenX, screenY)
      }
    }
    ctx.stroke()

    // Draw scaled function (2 * f(x))
    ctx.strokeStyle = "#FF5722"
    ctx.lineWidth = 3
    ctx.setLineDash([5, 5])
    ctx.beginPath()
    for (let x = a; x <= b; x += 0.1) {
      const screenX = 50 + ((x - a) / (b - a)) * (width - 100)
      const screenY = height - 50 - 2 * func(x) * 30
      if (x === a) {
        ctx.moveTo(screenX, screenY)
      } else {
        ctx.lineTo(screenX, screenY)
      }
    }
    ctx.stroke()
    ctx.setLineDash([])

    // Add sparkles for magic effect
    if (isAnimating) {
      ctx.fillStyle = "#FFD700"
      for (let i = 0; i < 10; i++) {
        const sparkleX = 50 + Math.random() * (width - 100)
        const sparkleY = 50 + Math.random() * (height - 100)
        const size = 2 + Math.sin(animationStep * 0.1 + i) * 2
        ctx.beginPath()
        ctx.arc(sparkleX, sparkleY, size, 0, 2 * Math.PI)
        ctx.fill()
      }
    }

    // Labels
    ctx.fillStyle = "#333"
    ctx.font = "14px Arial"
    ctx.fillText("f(x)", width - 100, height - 200)
    ctx.fillText("2·f(x)", width - 100, height - 300)
  }

  const drawAdditivity = () => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    const width = canvas.width
    const height = canvas.height

    // Clear with magical background
    const gradient = ctx.createLinearGradient(0, 0, 0, height)
    gradient.addColorStop(0, "#F3E5F5")
    gradient.addColorStop(1, "#E1BEE7")
    ctx.fillStyle = gradient
    ctx.fillRect(0, 0, width, height)

    // Draw coordinate system
    ctx.strokeStyle = "#666"
    ctx.lineWidth = 2
    ctx.beginPath()
    ctx.moveTo(50, height - 50)
    ctx.lineTo(width - 50, height - 50)
    ctx.moveTo(50, 50)
    ctx.lineTo(50, height - 50)
    ctx.stroke()

    const func = functions[currentFunction]
    const a = leftLimit
    const b = rightLimit
    const c = (a + b) / 2 // Middle point

    // Draw function
    ctx.strokeStyle = "#9C27B0"
    ctx.lineWidth = 3
    ctx.beginPath()
    for (let x = a; x <= b; x += 0.1) {
      const screenX = 50 + ((x - a) / (b - a)) * (width - 100)
      const screenY = height - 50 - func(x) * 30
      if (x === a) {
        ctx.moveTo(screenX, screenY)
      } else {
        ctx.lineTo(screenX, screenY)
      }
    }
    ctx.stroke()

    // Draw areas with different colors
    const n = partitions
    const dx1 = (c - a) / (n / 2)
    const dx2 = (b - c) / (n / 2)

    // First area [a, c]
    ctx.fillStyle = "rgba(76, 175, 80, 0.5)"
    for (let i = 0; i < n / 2; i++) {
      const x = a + i * dx1
      const height_rect = func(x + dx1 / 2)
      const screenX = 50 + ((x - a) / (b - a)) * (width - 100)
      const rectWidth = (dx1 / (b - a)) * (width - 100)
      const rectHeight = height_rect * 30

      ctx.fillRect(screenX, height - 50 - rectHeight, rectWidth, rectHeight)
    }

    // Second area [c, b]
    ctx.fillStyle = "rgba(255, 152, 0, 0.5)"
    for (let i = 0; i < n / 2; i++) {
      const x = c + i * dx2
      const height_rect = func(x + dx2 / 2)
      const screenX = 50 + ((x - a) / (b - a)) * (width - 100)
      const rectWidth = (dx2 / (b - a)) * (width - 100)
      const rectHeight = height_rect * 30

      ctx.fillRect(screenX, height - 50 - rectHeight, rectWidth, rectHeight)
    }

    // Draw dividing line at c
    ctx.strokeStyle = "#F44336"
    ctx.lineWidth = 3
    ctx.setLineDash([10, 5])
    const cScreenX = 50 + ((c - a) / (b - a)) * (width - 100)
    ctx.beginPath()
    ctx.moveTo(cScreenX, 50)
    ctx.lineTo(cScreenX, height - 50)
    ctx.stroke()
    ctx.setLineDash([])

    // Labels
    ctx.fillStyle = "#333"
    ctx.font = "14px Arial"
    ctx.fillText("∫[a,c] f(x)dx", 70, 80)
    ctx.fillText("∫[c,b] f(x)dx", width - 150, 80)
    ctx.fillText("c", cScreenX - 5, height - 30)
  }

  const drawMonotonicity = () => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    const width = canvas.width
    const height = canvas.height

    // Clear with magical background
    const gradient = ctx.createLinearGradient(0, 0, 0, height)
    gradient.addColorStop(0, "#FFF3E0")
    gradient.addColorStop(1, "#FFE0B2")
    ctx.fillStyle = gradient
    ctx.fillRect(0, 0, width, height)

    // Draw coordinate system
    ctx.strokeStyle = "#666"
    ctx.lineWidth = 2
    ctx.beginPath()
    ctx.moveTo(50, height - 50)
    ctx.lineTo(width - 50, height - 50)
    ctx.moveTo(50, 50)
    ctx.lineTo(50, height - 50)
    ctx.stroke()

    const func = functions[currentFunction]
    const a = leftLimit
    const b = rightLimit

    // Draw lower function f(x)
    ctx.strokeStyle = "#FF9800"
    ctx.lineWidth = 3
    ctx.beginPath()
    for (let x = a; x <= b; x += 0.1) {
      const screenX = 50 + ((x - a) / (b - a)) * (width - 100)
      const screenY = height - 50 - func(x) * 30
      if (x === a) {
        ctx.moveTo(screenX, screenY)
      } else {
        ctx.lineTo(screenX, screenY)
      }
    }
    ctx.stroke()

    // Draw higher function g(x) = f(x) + 1
    ctx.strokeStyle = "#E91E63"
    ctx.lineWidth = 3
    ctx.setLineDash([5, 5])
    ctx.beginPath()
    for (let x = a; x <= b; x += 0.1) {
      const screenX = 50 + ((x - a) / (b - a)) * (width - 100)
      const screenY = height - 50 - (func(x) + 1) * 30
      if (x === a) {
        ctx.moveTo(screenX, screenY)
      } else {
        ctx.lineTo(screenX, screenY)
      }
    }
    ctx.stroke()
    ctx.setLineDash([])

    // Fill areas to show comparison
    ctx.fillStyle = "rgba(255, 152, 0, 0.3)"
    ctx.beginPath()
    ctx.moveTo(50 + ((a - a) / (b - a)) * (width - 100), height - 50)
    for (let x = a; x <= b; x += 0.1) {
      const screenX = 50 + ((x - a) / (b - a)) * (width - 100)
      const screenY = height - 50 - func(x) * 30
      ctx.lineTo(screenX, screenY)
    }
    ctx.lineTo(50 + ((b - a) / (b - a)) * (width - 100), height - 50)
    ctx.closePath()
    ctx.fill()

    ctx.fillStyle = "rgba(233, 30, 99, 0.3)"
    ctx.beginPath()
    ctx.moveTo(50 + ((a - a) / (b - a)) * (width - 100), height - 50)
    for (let x = a; x <= b; x += 0.1) {
      const screenX = 50 + ((x - a) / (b - a)) * (width - 100)
      const screenY = height - 50 - (func(x) + 1) * 30
      ctx.lineTo(screenX, screenY)
    }
    ctx.lineTo(50 + ((b - a) / (b - a)) * (width - 100), height - 50)
    ctx.closePath()
    ctx.fill()

    // Labels
    ctx.fillStyle = "#333"
    ctx.font = "14px Arial"
    ctx.fillText("f(x)", width - 100, height - 150)
    ctx.fillText("g(x) = f(x) + 1", width - 150, height - 250)
  }

  const drawRiemannApproximation = () => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    const width = canvas.width
    const height = canvas.height

    // Clear with magical background
    const gradient = ctx.createLinearGradient(0, 0, 0, height)
    gradient.addColorStop(0, "#E8F5E8")
    gradient.addColorStop(1, "#C8E6C9")
    ctx.fillStyle = gradient
    ctx.fillRect(0, 0, width, height)

    // Draw coordinate system
    ctx.strokeStyle = "#666"
    ctx.lineWidth = 2
    ctx.beginPath()
    ctx.moveTo(50, height - 50)
    ctx.lineTo(width - 50, height - 50)
    ctx.moveTo(50, 50)
    ctx.lineTo(50, height - 50)
    ctx.stroke()

    const func = functions[currentFunction]
    const a = leftLimit
    const b = rightLimit

    // Draw function
    ctx.strokeStyle = "#4CAF50"
    ctx.lineWidth = 3
    ctx.beginPath()
    for (let x = a; x <= b; x += 0.1) {
      const screenX = 50 + ((x - a) / (b - a)) * (width - 100)
      const screenY = height - 50 - func(x) * 30
      if (x === a) {
        ctx.moveTo(screenX, screenY)
      } else {
        ctx.lineTo(screenX, screenY)
      }
    }
    ctx.stroke()

    // Animate increasing partitions
    const currentPartitions = isAnimating ? Math.floor(2 + (animationStep / 120) * 48) : partitions
    const dx = (b - a) / currentPartitions

    // Draw rectangles
    for (let i = 0; i < currentPartitions; i++) {
      const x = a + (i + 0.5) * dx // Middle point
      const height_rect = func(x)
      const screenX = 50 + ((a + i * dx - a) / (b - a)) * (width - 100)
      const rectWidth = (dx / (b - a)) * (width - 100)
      const rectHeight = height_rect * 30

      // Color based on accuracy
      const hue = 120 + (i * 60) / currentPartitions
      ctx.fillStyle = `hsla(${hue}, 70%, 60%, 0.7)`
      ctx.fillRect(screenX, height - 50 - rectHeight, rectWidth, rectHeight)

      // Draw flower on top for magic theme
      ctx.fillStyle = `hsl(${hue + 60}, 80%, 70%)`
      ctx.beginPath()
      ctx.arc(screenX + rectWidth / 2, height - 50 - rectHeight - 5, 3, 0, 2 * Math.PI)
      ctx.fill()
    }

    // Show partition count
    ctx.fillStyle = "#333"
    ctx.font = "16px Arial"
    ctx.fillText(`n = ${currentPartitions}`, width - 100, 80)
  }

  const drawFundamental = () => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    const width = canvas.width
    const height = canvas.height

    // Clear with magical background
    const gradient = ctx.createLinearGradient(0, 0, 0, height)
    gradient.addColorStop(0, "#FFF8E1")
    gradient.addColorStop(1, "#FFECB3")
    ctx.fillStyle = gradient
    ctx.fillRect(0, 0, width, height)

    // Draw coordinate system
    ctx.strokeStyle = "#666"
    ctx.lineWidth = 2
    ctx.beginPath()
    ctx.moveTo(50, height - 50)
    ctx.lineTo(width - 50, height - 50)
    ctx.moveTo(50, 50)
    ctx.lineTo(50, height - 50)
    ctx.stroke()

    const func = functions[currentFunction]
    const a = leftLimit
    const b = rightLimit

    // Draw function f(x)
    ctx.strokeStyle = "#FF6F00"
    ctx.lineWidth = 3
    ctx.beginPath()
    for (let x = a; x <= b; x += 0.1) {
      const screenX = 50 + ((x - a) / (b - a)) * (width - 100)
      const screenY = height - 50 - func(x) * 30
      if (x === a) {
        ctx.moveTo(screenX, screenY)
      } else {
        ctx.lineTo(screenX, screenY)
      }
    }
    ctx.stroke()

    // Fill area under curve
    ctx.fillStyle = "rgba(255, 111, 0, 0.3)"
    ctx.beginPath()
    ctx.moveTo(50 + ((a - a) / (b - a)) * (width - 100), height - 50)
    for (let x = a; x <= b; x += 0.1) {
      const screenX = 50 + ((x - a) / (b - a)) * (width - 100)
      const screenY = height - 50 - func(x) * 30
      ctx.lineTo(screenX, screenY)
    }
    ctx.lineTo(50 + ((b - a) / (b - a)) * (width - 100), height - 50)
    ctx.closePath()
    ctx.fill()

    // Draw F(b) - F(a) visualization
    const aScreenX = 50 + ((a - a) / (b - a)) * (width - 100)
    const bScreenX = 50 + ((b - a) / (b - a)) * (width - 100)

    // Vertical lines at a and b
    ctx.strokeStyle = "#D32F2F"
    ctx.lineWidth = 3
    ctx.setLineDash([5, 5])
    ctx.beginPath()
    ctx.moveTo(aScreenX, height - 50)
    ctx.lineTo(aScreenX, height - 50 - func(a) * 30)
    ctx.moveTo(bScreenX, height - 50)
    ctx.lineTo(bScreenX, height - 50 - func(b) * 30)
    ctx.stroke()
    ctx.setLineDash([])

    // Labels
    ctx.fillStyle = "#333"
    ctx.font = "14px Arial"
    ctx.fillText("F(b)", bScreenX + 5, height - 50 - func(b) * 30 - 5)
    ctx.fillText("F(a)", aScreenX + 5, height - 50 - func(a) * 30 - 5)
    ctx.fillText("∫f(x)dx = F(b) - F(a)", width - 200, 30)
  }

  const drawSubstitution = () => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    const width = canvas.width
    const height = canvas.height

    // Clear with magical background
    const gradient = ctx.createLinearGradient(0, 0, 0, height)
    gradient.addColorStop(0, "#F3E5F5")
    gradient.addColorStop(1, "#E1BEE7")
    ctx.fillStyle = gradient
    ctx.fillRect(0, 0, width, height)

    // Draw coordinate system
    ctx.strokeStyle = "#666"
    ctx.lineWidth = 2
    ctx.beginPath()
    ctx.moveTo(50, height - 50)
    ctx.lineTo(width - 50, height - 50)
    ctx.moveTo(50, 50)
    ctx.lineTo(50, height - 50)
    ctx.stroke()

    const func = functions[currentFunction]
    const a = leftLimit
    const b = rightLimit

    // Draw original function
    ctx.strokeStyle = "#7B1FA2"
    ctx.lineWidth = 3
    ctx.beginPath()
    for (let x = a; x <= b; x += 0.1) {
      const screenX = 50 + ((x - a) / (b - a)) * (width - 100)
      const screenY = height - 50 - func(x) * 30
      if (x === a) {
        ctx.moveTo(screenX, screenY)
      } else {
        ctx.lineTo(screenX, screenY)
      }
    }
    ctx.stroke()

    // Show transformation with animated effect
    if (isAnimating) {
      const t = (animationStep % 60) / 60 // 1 second cycle

      // Draw transformation arrows
      ctx.strokeStyle = "#E91E63"
      ctx.lineWidth = 2
      ctx.setLineDash([5, 5])

      for (let i = 0; i < 5; i++) {
        const x = a + (i / 4) * (b - a)
        const screenX = 50 + ((x - a) / (b - a)) * (width - 100)
        const screenY = height - 50 - func(x) * 30

        // Animated transformation arrow
        const arrowLength = 30 + 10 * Math.sin(t * 2 * Math.PI)
        ctx.beginPath()
        ctx.moveTo(screenX, screenY)
        ctx.lineTo(screenX + arrowLength, screenY - 20)
        ctx.stroke()

        // Arrow head
        ctx.beginPath()
        ctx.moveTo(screenX + arrowLength, screenY - 20)
        ctx.lineTo(screenX + arrowLength - 5, screenY - 15)
        ctx.moveTo(screenX + arrowLength, screenY - 20)
        ctx.lineTo(screenX + arrowLength - 5, screenY - 25)
        ctx.stroke()
      }
      ctx.setLineDash([])
    }

    // Labels
    ctx.fillStyle = "#333"
    ctx.font = "14px Arial"
    ctx.fillText("u = g(x)", width - 150, 80)
    ctx.fillText("du = g'(x)dx", width - 150, 100)
    ctx.fillText("Transformación", width - 150, 120)
  }

  // Main drawing function
  useEffect(() => {
    switch (activeProperty) {
      case "linearity":
        drawLinearity()
        break
      case "additivity":
        drawAdditivity()
        break
      case "monotonicity":
        drawMonotonicity()
        break
      case "riemann":
        drawRiemannApproximation()
        break
      case "fundamental":
        drawFundamental()
        break
      case "substitution":
        drawSubstitution()
        break
    }
  }, [activeProperty, isAnimating, animationStep, functions, currentFunction, leftLimit, rightLimit, partitions])

  const properties = [
    {
      id: "linearity",
      name: "Linealidad",
      icon: "🔗",
      description: "La integral de una combinación lineal es la combinación lineal de las integrales",
      formula: "∫[a,b] (c·f(x) + d·g(x))dx = c·∫[a,b] f(x)dx + d·∫[a,b] g(x)dx",
      explanation:
        "En nuestro jardín mágico, esto significa que si el hada mezcla dos pociones en proporciones específicas, puede calcular el efecto total sumando los efectos individuales multiplicados por sus proporciones. Esta propiedad es fundamental para resolver integrales complejas dividiéndolas en partes más simples.",
      detailedExample:
        "Si tenemos 3·sen(x) + 2·cos(x), podemos integrar cada término por separado y luego combinar los resultados.",
      gardenExample: `Con tu función actual ${currentFunction}, si multiplicamos por 2: ∫[${leftLimit},${rightLimit}] 2·f(x)dx = 2·∫[${leftLimit},${rightLimit}] f(x)dx`,
      theory: {
        title: "Teoría de la Linealidad",
        content: `
          La propiedad de linealidad es fundamental en el cálculo integral y se basa en dos sub-propiedades:
          
          1. **Homogeneidad**: ∫[a,b] c·f(x)dx = c·∫[a,b] f(x)dx
             - Las constantes pueden "salir" de la integral
             - En el jardín: si duplicas la altura de todas las macetas, duplicas el área total
          
          2. **Aditividad de funciones**: ∫[a,b] (f(x) + g(x))dx = ∫[a,b] f(x)dx + ∫[a,b] g(x)dx
             - La integral de una suma es la suma de las integrales
             - En el jardín: plantar dos tipos de flores es como sumar dos jardines separados
          
          **Demostración con Sumas de Riemann:**
          ∫[a,b] (c·f(x) + d·g(x))dx = lim(n→∞) Σ[c·f(xi) + d·g(xi)]·Δx
                                      = lim(n→∞) [c·Σf(xi)·Δx + d·Σg(xi)·Δx]
                                      = c·∫[a,b] f(x)dx + d·∫[a,b] g(x)dx
        `,
      },
    },
    {
      id: "additivity",
      name: "Aditividad",
      icon: "➕",
      description: "El área total es la suma de las áreas parciales cuando dividimos el intervalo",
      formula: "∫[a,c] f(x)dx + ∫[c,b] f(x)dx = ∫[a,b] f(x)dx",
      explanation:
        "Si dividimos nuestro jardín en dos secciones con una cerca mágica, la cantidad total de tierra mágica es la suma de la tierra en cada sección. Esta propiedad nos permite calcular integrales en intervalos complicados dividiéndolos en partes más manejables.",
      detailedExample: "Para calcular ∫[0,4] f(x)dx, podemos dividirlo en ∫[0,2] f(x)dx + ∫[2,4] f(x)dx",
      gardenExample: `En tu jardín [${leftLimit},${rightLimit}], si dividimos en c=${((leftLimit + rightLimit) / 2).toFixed(1)}: ∫[${leftLimit},${((leftLimit + rightLimit) / 2).toFixed(1)}] + ∫[${((leftLimit + rightLimit) / 2).toFixed(1)},${rightLimit}] = ∫[${leftLimit},${rightLimit}]`,
      theory: {
        title: "Teoría de la Aditividad",
        content: `
          La aditividad de intervalos es una propiedad geométrica fundamental que refleja cómo medimos áreas.
          
          **Interpretación Geométrica:**
          - Si tienes una región bajo una curva de a hasta b
          - Y la divides en cualquier punto c donde a ≤ c ≤ b
          - El área total es la suma de las dos áreas parciales
          
          **Demostración Intuitiva:**
          Las macetas del jardín no se superponen ni dejan espacios vacíos. Si cuentas las macetas de la izquierda y las de la derecha por separado, obtienes el mismo total que contarlas todas juntas.
          
          **Aplicaciones Prácticas:**
          - Calcular integrales en intervalos donde la función cambia de comportamiento
          - Dividir problemas complejos en partes más simples
          - Base para la integración por partes y sustitución
          
          **Extensión a múltiples intervalos:**
          ∫[a,d] f(x)dx = ∫[a,b] f(x)dx + ∫[b,c] f(x)dx + ∫[c,d] f(x)dx
        `,
      },
    },
    {
      id: "monotonicity",
      name: "Monotonía",
      icon: "📈",
      description: "Si una función es mayor o igual que otra, su integral también será mayor o igual",
      formula: "Si f(x) ≤ g(x) en [a,b], entonces ∫[a,b] f(x)dx ≤ ∫[a,b] g(x)dx",
      explanation:
        "Un jardín más alto siempre necesitará más tierra mágica. Si una cerca es más alta que otra en todo el jardín, el área bajo la cerca más alta será mayor. Esta propiedad nos ayuda a comparar integrales sin calcularlas exactamente.",
      detailedExample: "Como x² ≥ 0 para todo x, sabemos que ∫[a,b] x²dx ≥ 0 sin necesidad de calcular la integral.",
      gardenExample: `Tu función ${currentFunction} vs una función constante: si f(x) ≥ 2 en [${leftLimit},${rightLimit}], entonces ∫f(x)dx ≥ 2·(${rightLimit}-${leftLimit}) = ${(2 * (rightLimit - leftLimit)).toFixed(2)}`,
      theory: {
        title: "Teoría de la Monotonía",
        content: `
          La propiedad de monotonía establece un orden entre integrales basado en el orden entre funciones.
          
          **Enunciado Formal:**
          Si f(x) ≤ g(x) para todo x ∈ [a,b], entonces ∫[a,b] f(x)dx ≤ ∫[a,b] g(x)dx
          
          **Demostración con Sumas de Riemann:**
          Si f(xi) ≤ g(xi) para todo i, entonces:
          Σf(xi)·Δx ≤ Σg(xi)·Δx
          
          Tomando el límite cuando n→∞:
          ∫[a,b] f(x)dx ≤ ∫[a,b] g(x)dx
          
          **Aplicaciones:**
          1. **Estimación de integrales**: Acotar integrales difíciles entre funciones más simples
          2. **Teoremas de comparación**: Determinar convergencia de integrales impropias
          3. **Optimización**: Encontrar máximos y mínimos de funcionales
          
          **Ejemplo en el jardín:**
          Si todas las macetas de un jardín son más altas que las de otro, el primer jardín tendrá más área total.
        `,
      },
    },
    {
      id: "riemann",
      name: "Sumas de Riemann",
      icon: "🎯",
      description:
        "La integral definida es el límite de las sumas de Riemann cuando las particiones tienden a infinito",
      formula: "∫[a,b] f(x)dx = lim(n→∞) Σ(i=1 to n) f(xi)Δx, donde Δx = (b-a)/n",
      explanation:
        "Mientras más macetas pequeñas plantemos, mejor aproximaremos la cantidad real de tierra mágica. En el límite, cuando usamos infinitas macetas infinitamente pequeñas, obtenemos el valor exacto de la integral. Este es el concepto fundamental que define qué es una integral.",
      detailedExample:
        "Con n=4 rectángulos obtenemos una aproximación burda, pero con n=1000 la aproximación es muy precisa.",
      gardenExample: `En tu jardín con ${partitions} macetas, cada una tiene ancho Δx = ${((rightLimit - leftLimit) / partitions).toFixed(3)}. ¡Prueba aumentar a ${partitions * 2} macetas para mejor precisión!`,
      theory: {
        title: "Teoría de las Sumas de Riemann",
        content: `
          Las sumas de Riemann son la definición formal de la integral definida, desarrollada por Bernhard Riemann en el siglo XIX.
          
          **Definición Formal:**
          Para una función f(x) en [a,b], dividimos el intervalo en n subintervalos de ancho Δx = (b-a)/n.
          En cada subintervalo [xi, xi+1], elegimos un punto ci y formamos la suma:
          
          Sn = Σ(i=1 to n) f(ci)·Δx
          
          **Tipos de Sumas de Riemann:**
          1. **Izquierda**: ci = xi (extremo izquierdo)
          2. **Derecha**: ci = xi+1 (extremo derecho)  
          3. **Punto medio**: ci = (xi + xi+1)/2
          4. **Punto arbitrario**: ci puede ser cualquier punto en [xi, xi+1]
          
          **Convergencia:**
          Si f es continua en [a,b], entonces:
          ∫[a,b] f(x)dx = lim(n→∞) Sn
          
          independientemente de cómo elijamos los puntos ci.
          
          **En el jardín mágico:**
          - Cada maceta representa un término f(ci)·Δx
          - Más macetas = mejor aproximación
          - En el límite: infinitas macetas infinitamente delgadas = área exacta
        `,
      },
    },
    {
      id: "fundamental",
      name: "Teorema Fundamental",
      icon: "⚡",
      description: "Conecta la derivación con la integración: son operaciones inversas",
      formula: "Si F'(x) = f(x), entonces ∫[a,b] f(x)dx = F(b) - F(a)",
      explanation:
        "Este es el hechizo más poderoso del jardín mágico. Nos dice que si conocemos una función cuya derivada es f(x), podemos calcular la integral exacta simplemente evaluando esa función en los extremos. Es como tener una varita mágica que convierte problemas difíciles en cálculos simples.",
      detailedExample: "Para ∫[0,2] 2x dx, como F(x) = x² tiene derivada 2x, la respuesta es F(2) - F(0) = 4 - 0 = 4.",
      gardenExample: `Para tu función ${currentFunction} en [${leftLimit},${rightLimit}], encontrar su antiderivada F(x) nos permite calcular F(${rightLimit}) - F(${leftLimit}) directamente.`,
      theory: {
        title: "Teorema Fundamental del Cálculo",
        content: `
          El Teorema Fundamental del Cálculo es uno de los resultados más importantes de las matemáticas, conectando derivadas e integrales.
          
          **Primera Parte (TFC1):**
          Si f es continua en [a,b] y F(x) = ∫[a,x] f(t)dt, entonces F'(x) = f(x).
          
          **Segunda Parte (TFC2):**
          Si f es continua en [a,b] y F es cualquier antiderivada de f, entonces:
          ∫[a,b] f(x)dx = F(b) - F(a)
          
          **Significado Profundo:**
          - La derivación e integración son operaciones inversas
          - Podemos evaluar integrales definidas sin límites de sumas
          - Conecta el problema geométrico (área) con el algebraico (antiderivadas)
          
          **Demostración Intuitiva:**
          Si F'(x) = f(x), entonces F mide la "acumulación" de f desde un punto fijo.
          La diferencia F(b) - F(a) es exactamente la acumulación total de f en [a,b].
          
          **En el jardín:**
          En lugar de contar macetas una por una, el TFC nos da una fórmula mágica para calcular el área total instantáneamente.
        `,
      },
    },
    {
      id: "substitution",
      name: "Sustitución",
      icon: "🔄",
      description: "Cambio de variable para simplificar integrales complicadas",
      formula: "∫[a,b] f(g(x))g'(x)dx = ∫[g(a),g(b)] f(u)du, donde u = g(x)",
      explanation:
        "A veces nuestro jardín tiene una forma complicada, pero podemos usar magia para transformarlo en una forma más simple. La sustitución es como usar un hechizo de transformación que cambia las coordenadas del jardín para hacer más fácil el cálculo del área mágica.",
      detailedExample: "Para ∫ 2x·cos(x²)dx, sustituimos u = x², du = 2x dx, obteniendo ∫ cos(u)du = sen(u) = sen(x²).",
      gardenExample: `Si tu función ${currentFunction} fuera parte de una composición f(g(x))·g'(x), podrías transformar el jardín con u = g(x) para simplificar el cálculo.`,
      theory: {
        title: "Teoría de la Sustitución",
        content: `
          La regla de sustitución (o cambio de variable) es la versión integral de la regla de la cadena para derivadas.
          
          **Teorema de Sustitución:**
          Si g'(x) es continua en [a,b] y f es continua en el rango de g, entonces:
          ∫[a,b] f(g(x))g'(x)dx = ∫[g(a),g(b)] f(u)du
          
          **Proceso de Sustitución:**
          1. Identificar u = g(x)
          2. Calcular du = g'(x)dx
          3. Cambiar los límites: cuando x = a, u = g(a); cuando x = b, u = g(b)
          4. Reescribir la integral en términos de u
          5. Evaluar la nueva integral
          6. (Si es indefinida) Sustituir de vuelta a x
          
          **Justificación:**
          Basada en el Teorema Fundamental del Cálculo y la regla de la cadena:
          Si F'(u) = f(u), entonces d/dx[F(g(x))] = F'(g(x))·g'(x) = f(g(x))·g'(x)
          
          **En el jardín mágico:**
          Es como usar un mapa mágico que transforma un jardín de forma irregular en uno rectangular, donde es más fácil calcular el área.
        `,
      },
    },
  ]

  return (
    <Card className="p-6 bg-white/95 backdrop-blur">
      <div className="flex items-center gap-2 mb-4">
        <Sparkles className="w-6 h-6 text-purple-600" />
        <h2 className="text-2xl font-bold text-green-800">Propiedades Mágicas de las Integrales</h2>
        <Button onClick={() => setShowTheory(!showTheory)} variant="outline" size="sm" className="ml-auto">
          📖 {showTheory ? "Ocultar" : "Ver"} Teoría
        </Button>
      </div>

      <Tabs value={activeProperty} onValueChange={setActiveProperty} className="w-full">
        <TabsList className="grid w-full grid-cols-3 lg:grid-cols-6 mb-6">
          {properties.map((prop) => (
            <TabsTrigger key={prop.id} value={prop.id} className="flex items-center gap-1 text-xs">
              <span>{prop.icon}</span>
              <span className="hidden sm:inline">{prop.name}</span>
            </TabsTrigger>
          ))}
        </TabsList>

        {properties.map((prop) => (
          <TabsContent key={prop.id} value={prop.id} className="space-y-4">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Visualization Canvas */}
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-lg font-semibold text-green-800">
                    {prop.icon} {prop.name}
                  </h3>
                  <div className="flex gap-2">
                    <Button
                      onClick={() => setIsAnimating(!isAnimating)}
                      size="sm"
                      variant={isAnimating ? "destructive" : "default"}
                    >
                      {isAnimating ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                      {isAnimating ? "Pausar" : "Animar"}
                    </Button>
                    <Button
                      onClick={() => {
                        setIsAnimating(false)
                        setAnimationStep(0)
                      }}
                      size="sm"
                      variant="outline"
                    >
                      <RotateCcw className="w-4 h-4" />
                    </Button>
                  </div>
                </div>

                <div className="border-2 border-green-300 rounded-lg overflow-hidden">
                  <canvas ref={canvasRef} width={400} height={300} className="w-full" />
                </div>

                {prop.id === "riemann" && isAnimating && (
                  <Badge className="bg-green-500 text-white">
                    Observa cómo mejora la aproximación con más particiones
                  </Badge>
                )}
              </div>

              {/* Explanation */}
              <div className="space-y-4">
                <div className="p-4 bg-blue-50 rounded-lg">
                  <h4 className="font-semibold text-blue-800 mb-2">Descripción</h4>
                  <p className="text-blue-700 text-sm">{prop.description}</p>
                </div>

                <div className="p-4 bg-purple-50 rounded-lg">
                  <h4 className="font-semibold text-purple-800 mb-2">Fórmula Matemática</h4>
                  <p className="text-purple-700 text-sm font-mono bg-white p-2 rounded border">{prop.formula}</p>
                </div>

                <div className="p-4 bg-green-50 rounded-lg">
                  <h4 className="font-semibold text-green-800 mb-2">En el Jardín Mágico</h4>
                  <p className="text-green-700 text-sm">{prop.explanation}</p>
                </div>

                <div className="p-4 bg-orange-50 rounded-lg">
                  <h4 className="font-semibold text-orange-800 mb-2">Ejemplo Detallado</h4>
                  <p className="text-orange-700 text-sm">{prop.detailedExample}</p>
                </div>

                <div className="p-4 bg-yellow-50 rounded-lg">
                  <h4 className="font-semibold text-yellow-800 mb-2">Ejemplo con Tu Jardín Actual</h4>
                  <div className="text-yellow-700 text-sm space-y-1">
                    <p>
                      Función: <span className="font-mono">{currentFunction}</span>
                    </p>
                    <p>
                      Límites: [{leftLimit}, {rightLimit}]
                    </p>
                    <p>Particiones: {partitions}</p>
                    <p className="mt-2 p-2 bg-white rounded border">
                      <strong>Aplicación:</strong> {prop.gardenExample}
                    </p>
                  </div>
                </div>

                {showTheory && (
                  <div className="p-4 bg-indigo-50 rounded-lg border-2 border-indigo-200">
                    <h4 className="font-semibold text-indigo-800 mb-3 flex items-center gap-2">
                      📚 {prop.theory.title}
                    </h4>
                    <div className="text-indigo-700 text-sm whitespace-pre-line leading-relaxed">
                      {prop.theory.content}
                    </div>
                  </div>
                )}
              </div>
            </div>
          </TabsContent>
        ))}
      </Tabs>
    </Card>
  )
}
