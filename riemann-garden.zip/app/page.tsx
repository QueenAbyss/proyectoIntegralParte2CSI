"use client"

import { useState } from "react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Slider } from "@/components/ui/slider"
import { Badge } from "@/components/ui/badge"
import { Play, Pause, RotateCcw, BookOpen, MousePointer, Hand } from "lucide-react"
import { TutorialSystem, type TutorialStep } from "@/components/tutorial-system"
import { DraggableCanvas } from "@/components/draggable-canvas"
import { PropertiesVisualizer } from "@/components/properties-visualizer"
import { ErrorVerification } from "@/components/error-verification"

// Mathematical functions for the garden
const functions = {
  quadratic: (x: number) => 0.5 * x * x + 1,
  sine: (x: number) => 2 * Math.sin(x) + 3,
  cubic: (x: number) => 0.1 * x * x * x + 0.5 * x * x + 2,
}

type FunctionType = keyof typeof functions

const tutorialSteps: TutorialStep[] = [
  {
    id: 1,
    title: "¡Bienvenida al Jardín Mágico!",
    description:
      "Soy Aria, el hada jardinera. Te ayudaré a entender las integrales de Riemann plantando macetas mágicas en nuestro jardín encantado.",
    target: "fairy",
    position: { x: 50, y: 20 },
    fairyMessage:
      "¡Hola! Estoy muy emocionada de enseñarte sobre las integrales. ¿Estás listo para esta aventura mágica?",
    hint: "💡 Las integrales de Riemann son una forma de calcular el área bajo una curva dividiéndola en pequeños rectángulos. ¡Es como contar cuadraditos en papel cuadriculado, pero de forma más precisa!",
    isObservationOnly: true,
  },
  {
    id: 2,
    title: "La Cerca Mágica",
    description:
      "Esta cerca ondulada representa nuestra función f(x). Necesitamos calcular cuánta tierra mágica hay debajo de ella para plantar nuestras flores.",
    target: "canvas",
    position: { x: 400, y: 150 },
    action: "Observa cómo la curva morada forma la cerca de nuestro jardín",
    fairyMessage: "Esta cerca cambia de altura. Nuestra misión es encontrar el área total debajo de ella.",
    hint: "🔍 La función f(x) = 0.5x² + 1 es una parábola que siempre es positiva. Su forma crea un área específica entre los límites que podemos calcular exactamente, pero las integrales de Riemann nos permiten aproximarla usando rectángulos.",
    isObservationOnly: true,
  },
  {
    id: 3,
    title: "Macetas de Aproximación",
    description:
      "Estas macetas coloridas representan los rectángulos de Riemann. Cada maceta nos ayuda a aproximar el área bajo la cerca. ¡Más macetas significan mejor aproximación!",
    target: "canvas",
    position: { x: 300, y: 300 },
    action: "Observa cómo las macetas se ajustan bajo la cerca",
    fairyMessage: "Cada maceta tiene una altura específica. Juntas, nos dan una idea del área total.",
    hint: "📐 Cada rectángulo tiene un ancho fijo (Δx = (b-a)/n) y una altura determinada por el valor de la función en un punto específico. La suma de todas las áreas rectangulares nos da la aproximación: Σf(xi)·Δx",
    isObservationOnly: true,
  },
  {
    id: 4,
    title: "Cristal de Particiones",
    description:
      "Este cristal mágico controla cuántas macetas plantamos. Muévelo para ver cómo más macetas nos dan una aproximación más precisa del área real.",
    target: "#partitions-slider",
    position: { x: 150, y: 500 },
    action: "Mueve el deslizador para cambiar el número de macetas",
    fairyMessage: "¡Experimenta! Verás que más macetas pequeñas aproximan mejor el área verdadera.",
    hint: "🎯 Prueba estos valores para ver la mejora: 8 macetas (error ~0.5), 16 macetas (error ~0.25), 32 macetas (error ~0.12). ¡Nota cómo el error se reduce aproximadamente a la mitad cada vez que duplicas las particiones!",
    requirement: (partitions: number[]) => {
      console.log("[v0] Checking partitions requirement:", partitions)
      const hasChanged = partitions && partitions[0] !== 8
      console.log("[v0] Requirement result:", hasChanged)
      return hasChanged
    },
  },
  {
    id: 5,
    title: "Cristales de Límites Mágicos",
    description:
      "Estos cristales rojos y azules marcan dónde empieza y termina nuestro jardín. En el modo libre, podrás arrastrarlos directamente en el gráfico.",
    target: "#limits",
    position: { x: 500, y: 400 },
    action: "Ajusta los límites izquierdo y derecho del jardín",
    fairyMessage: "Los límites de integración definen exactamente qué parte del jardín estamos midiendo.",
    hint: "📏 Los límites de integración [a,b] definen el intervalo donde calculamos el área. Si cambias de [-2,4] a [-1,3], estás calculando ∫₋₁³ f(x)dx en lugar de ∫₋₂⁴ f(x)dx. ¡Prueba [-1,2] para ver un área más pequeña!",
    requirement: (leftLimit: number[], rightLimit: number[]) => {
      console.log("[v0] Checking limits requirement:", leftLimit, rightLimit)
      return leftLimit && rightLimit && (leftLimit[0] !== -2 || rightLimit[0] !== 4)
    },
  },
  {
    id: 6,
    title: "Tipos de Hechizo",
    description:
      "Podemos usar diferentes hechizos para determinar la altura de cada maceta: por la izquierda, derecha, o centro de cada sección.",
    target: "#approximation-type",
    position: { x: 600, y: 300 },
    action: "Prueba los diferentes tipos de aproximación",
    fairyMessage: "Cada hechizo da un resultado ligeramente diferente. ¡El del centro suele ser el más preciso!",
    hint: "⚖️ Método Izquierdo: usa f(xi) donde xi es el extremo izquierdo. Método Derecho: usa f(xi+1). Método Centro: usa f((xi+xi+1)/2). Para funciones cóncavas hacia arriba como nuestra parábola, el método del centro es más preciso porque compensa mejor la curvatura.",
    isObservationOnly: true,
  },
  {
    id: 7,
    title: "¡Felicidades, Aprendiz!",
    description:
      "Has completado el tutorial básico. Ahora puedes explorar libremente el jardín mágico y experimentar con todas las herramientas. ¡En el modo libre podrás arrastrar elementos directamente!",
    target: "completion",
    position: { x: 300, y: 200 },
    fairyMessage:
      "¡Excelente trabajo! Ahora eres oficialmente mi aprendiz de jardinería mágica. ¡Ve y experimenta arrastrando los elementos!",
    hint: "🌟 ¡Ahora eres un experto en integrales de Riemann! En el modo libre puedes: arrastrar los límites directamente en el gráfico, probar diferentes funciones (seno, cúbica), y ver cómo el error disminuye con más particiones. ¡La integral exacta es tu objetivo!",
    isObservationOnly: true,
  },
]

export default function RiemannGarden() {
  // State management
  const [mode, setMode] = useState<"guided" | "free">("free")
  const [currentFunction, setCurrentFunction] = useState<FunctionType>("quadratic")
  const [partitions, setPartitions] = useState([8])
  const [leftLimit, setLeftLimit] = useState([-2])
  const [rightLimit, setRightLimit] = useState([4])
  const [approximationType, setApproximationType] = useState<"left" | "right" | "middle">("middle")
  const [showArea, setShowArea] = useState(true)
  const [tutorialStep, setTutorialStep] = useState(0)
  const [tutorialActive, setTutorialActive] = useState(false)
  const [isPlaying, setIsPlaying] = useState(false)
  const [showProperties, setShowProperties] = useState(false)
  const [activeProperty, setActiveProperty] = useState("linearity")
  const [showErrorVerification, setShowErrorVerification] = useState(true)
  const [simulationCompleted, setSimulationCompleted] = useState(false)
  const [showPropertiesInMain, setShowPropertiesInMain] = useState(false)

  const getFunctionDisplay = () => {
    switch (currentFunction) {
      case "quadratic":
        return "f(x) = 0.5x² + 1"
      case "sine":
        return "f(x) = 2sin(x) + 3"
      case "cubic":
        return "f(x) = 0.1x³ + 0.5x² + 2"
      default:
        return "f(x)"
    }
  }

  const getFunctionName = () => {
    switch (currentFunction) {
      case "quadratic":
        return "Parábola Mágica"
      case "sine":
        return "Onda Senoidal"
      case "cubic":
        return "Curva Cúbica"
      default:
        return "Función"
    }
  }

  // Mathematical calculations
  const calculateRiemannSum = () => {
    const a = leftLimit[0]
    const b = rightLimit[0]
    const n = partitions[0]
    const dx = (b - a) / n
    const func = functions[currentFunction]

    let sum = 0
    for (let i = 0; i < n; i++) {
      let x: number
      switch (approximationType) {
        case "left":
          x = a + i * dx
          break
        case "right":
          x = a + (i + 1) * dx
          break
        case "middle":
          x = a + (i + 0.5) * dx
          break
      }
      sum += func(x) * dx
    }
    return sum
  }

  const calculateExactIntegral = () => {
    const a = leftLimit[0]
    const b = rightLimit[0]

    // Exact integrals for our functions
    switch (currentFunction) {
      case "quadratic":
        return (0.5 * b * b * b) / 3 + (b * b) / 2 - ((0.5 * a * a * a) / 3 + (a * a) / 2)
      case "sine":
        return -2 * Math.cos(b) + 3 * b - (-2 * Math.cos(a) + 3 * a)
      case "cubic":
        return (
          (0.1 * b * b * b * b) / 4 +
          (0.5 * b * b * b) / 3 +
          2 * b -
          ((0.1 * a * a * a * a) / 4 + (0.5 * a * a * a) / 3 + 2 * a)
        )
    }
  }

  const getError = () => {
    const approximate = calculateRiemannSum()
    const exact = calculateExactIntegral()
    return Math.abs(approximate - exact)
  }

  const isApproximationGood = () => {
    return getError() < 0.1 // Tolerance for "good" approximation
  }

  const startTutorial = () => {
    setMode("guided")
    setTutorialActive(true)
    setTutorialStep(1)
    // Reset to default values for tutorial
    setPartitions([8])
    setLeftLimit([-2])
    setRightLimit([4])
    setCurrentFunction("quadratic")
    setApproximationType("middle")
    setSimulationCompleted(false)
  }

  const completeTutorial = () => {
    setTutorialActive(false)
    setTutorialStep(0)
    setMode("free")
  }

  const handleLimitChange = (left: number, right: number) => {
    setLeftLimit([left])
    setRightLimit([right])
  }

  const handleFunctionPointDrag = (x: number, y: number) => {
    // This could be used to modify function parameters in the future
    console.log(`Function point dragged to: (${x}, ${y})`)
  }

  const handleSimulationSuccess = () => {
    setSimulationCompleted(true)
    setIsPlaying(false)
  }

  const handleSimulationReset = () => {
    setSimulationCompleted(false)
    setPartitions([8])
    setLeftLimit([-2])
    setRightLimit([4])
    setCurrentFunction("quadratic")
    setApproximationType("middle")
  }

  const handleTutorialStepChange = (newStep: number) => {
    console.log("[v0] Tutorial step changing from", tutorialStep, "to", newStep)
    setTutorialStep(newStep)
  }

  const calculateRiemannSumForInterval = (start: number, end: number) => {
    const n = Math.floor(partitions[0] / 2) // Use half the partitions for each part
    const dx = (end - start) / n
    const func = functions[currentFunction]

    let sum = 0
    for (let i = 0; i < n; i++) {
      let x: number
      switch (approximationType) {
        case "left":
          x = start + i * dx
          break
        case "right":
          x = start + (i + 1) * dx
          break
        case "middle":
          x = start + (i + 0.5) * dx
          break
      }
      sum += func(x) * dx
    }
    return sum
  }

  const demonstrateLinearity = () => {
    const originalSum = calculateRiemannSum()
    const scaledSum = originalSum * 2 // Demonstrate c·∫f(x)dx = ∫c·f(x)dx
    return { original: originalSum, scaled: scaledSum }
  }

  const demonstrateAdditivity = () => {
    const a = leftLimit[0]
    const b = rightLimit[0]
    const c = (a + b) / 2

    // Calculate ∫[a,c] + ∫[c,b] and compare with ∫[a,b]
    const leftPart = calculateRiemannSumForInterval(a, c)
    const rightPart = calculateRiemannSumForInterval(c, b)
    const total = calculateRiemannSum()

    return { leftPart, rightPart, sum: leftPart + rightPart, total }
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-200 via-green-200 to-green-400 p-4">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="text-center mb-6">
          <h1 className="text-4xl font-bold text-green-800 mb-2">🧚‍♀️ El Jardín Mágico de Riemann 🌸</h1>
          <p className="text-green-700 text-lg">
            Aprende integrales definidas plantando macetas mágicas con el Hada Aria
          </p>
          <div className="mt-3 p-3 bg-white/80 rounded-lg border border-green-300 inline-block">
            <div className="text-sm text-green-600 mb-1">Función Actual:</div>
            <div className="text-lg font-bold text-green-800">{getFunctionDisplay()}</div>
            <div className="text-sm text-green-600">{getFunctionName()}</div>
          </div>
          {mode === "free" && (
            <div className="mt-2 flex items-center justify-center gap-2 text-sm text-green-600">
              <Hand className="w-4 h-4" />
              <span>Arrastra los puntos rojos y azules para cambiar los límites de integración</span>
            </div>
          )}
        </div>

        {/* Mode Selection */}
        <div className="flex justify-center gap-4 mb-6">
          <Button
            onClick={startTutorial}
            variant={mode === "guided" ? "default" : "outline"}
            className="flex items-center gap-2"
          >
            <BookOpen className="w-4 h-4" />
            Modo Guiado
          </Button>
          <Button
            onClick={() => {
              setMode("free")
              setTutorialActive(false)
              setTutorialStep(0)
            }}
            variant={mode === "free" ? "default" : "outline"}
            className="flex items-center gap-2"
          >
            <MousePointer className="w-4 h-4" />
            Modo Libre
          </Button>
          <Button
            onClick={() => setShowProperties(!showProperties)}
            variant={showProperties ? "default" : "outline"}
            className="flex items-center gap-2"
          >
            ✨ Propiedades Mágicas
          </Button>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Main Canvas */}
          <div className="lg:col-span-3">
            <Card className="p-4 bg-white/90 backdrop-blur">
              <div className="relative">
                <DraggableCanvas
                  width={800}
                  height={500}
                  functions={functions}
                  currentFunction={currentFunction}
                  partitions={partitions[0]}
                  leftLimit={leftLimit[0]}
                  rightLimit={rightLimit[0]}
                  approximationType={approximationType}
                  showArea={showArea}
                  onLimitChange={handleLimitChange}
                  onFunctionPointDrag={handleFunctionPointDrag}
                  mode={mode}
                  tutorialStep={tutorialStep}
                />
              </div>

              {/* Results Display */}
              <div className="mt-4 grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="text-center p-3 bg-blue-100 rounded-lg">
                  <div className="text-sm text-blue-600">Aproximación de Riemann</div>
                  <div className="text-xl font-bold text-blue-800">{calculateRiemannSum().toFixed(4)}</div>
                  <div className="text-xs text-blue-500 mt-1">Σf(xi)·Δx con {partitions[0]} términos</div>
                </div>
                <div className="text-center p-3 bg-green-100 rounded-lg">
                  <div className="text-sm text-green-600">Integral Exacta</div>
                  <div className="text-xl font-bold text-green-800">{calculateExactIntegral().toFixed(4)}</div>
                  <div className="text-xs text-green-500 mt-1">Teorema Fundamental del Cálculo</div>
                </div>
                <div className="text-center p-3 bg-purple-100 rounded-lg">
                  <div className="text-sm text-purple-600">Error</div>
                  <div className="text-xl font-bold text-purple-800">{getError().toFixed(4)}</div>
                  {isApproximationGood() && <Badge className="mt-1 bg-green-500">¡Excelente!</Badge>}
                  <div className="text-xs text-purple-500 mt-1">|Aproximación - Exacta|</div>
                </div>
              </div>

              <div className="mt-4 p-4 bg-gradient-to-r from-purple-50 to-blue-50 rounded-lg border border-purple-200">
                <h4 className="font-semibold text-purple-800 mb-3 flex items-center gap-2">
                  🔬 Demostración de Propiedades en Tu Jardín
                  <Button onClick={() => setShowPropertiesInMain(!showPropertiesInMain)} variant="outline" size="sm">
                    {showPropertiesInMain ? "Ocultar" : "Ver Más"}
                  </Button>
                </h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                  <div className="p-3 bg-white rounded border">
                    <strong className="text-blue-700">🔗 Linealidad:</strong>
                    <div className="mt-1">∫f(x)dx = {calculateRiemannSum().toFixed(3)}</div>
                    <div>2·∫f(x)dx = {(calculateRiemannSum() * 2).toFixed(3)}</div>
                    <div className="text-xs text-blue-500 mt-1">
                      Si duplicas la altura de todas las macetas, duplicas el área total
                    </div>
                  </div>
                  <div className="p-3 bg-white rounded border">
                    <strong className="text-green-700">➕ Aditividad:</strong>
                    <div className="mt-1">
                      ∫[a,c] ={" "}
                      {calculateRiemannSumForInterval(leftLimit[0], (leftLimit[0] + rightLimit[0]) / 2).toFixed(3)}
                    </div>
                    <div>
                      ∫[c,b] ={" "}
                      {calculateRiemannSumForInterval((leftLimit[0] + rightLimit[0]) / 2, rightLimit[0]).toFixed(3)}
                    </div>
                    <div className="border-t pt-1 mt-1">
                      Suma ={" "}
                      {(
                        calculateRiemannSumForInterval(leftLimit[0], (leftLimit[0] + rightLimit[0]) / 2) +
                        calculateRiemannSumForInterval((leftLimit[0] + rightLimit[0]) / 2, rightLimit[0])
                      ).toFixed(3)}
                    </div>
                    <div className="text-xs text-green-500 mt-1">
                      Dividir el jardín en dos partes da la misma área total
                    </div>
                  </div>
                  {showPropertiesInMain && (
                    <>
                      <div className="p-3 bg-white rounded border">
                        <strong className="text-orange-700">📈 Monotonía:</strong>
                        <div className="mt-1">Si f(x) ≥ g(x), entonces ∫f(x)dx ≥ ∫g(x)dx</div>
                        <div className="text-xs text-orange-500 mt-1">Un jardín más alto siempre tiene más área</div>
                      </div>
                      <div className="p-3 bg-white rounded border">
                        <strong className="text-red-700">🎯 Sumas de Riemann:</strong>
                        <div className="mt-1">Δx = {((rightLimit[0] - leftLimit[0]) / partitions[0]).toFixed(3)}</div>
                        <div>n = {partitions[0]} macetas</div>
                        <div className="text-xs text-red-500 mt-1">Más macetas = mejor aproximación al área real</div>
                      </div>
                    </>
                  )}
                </div>
              </div>
            </Card>
          </div>

          {/* Controls Panel */}
          <div className="space-y-4">
            {/* Function Selection */}
            <Card className="p-4 bg-white/90 backdrop-blur">
              <h3 className="font-semibold mb-3 text-green-800">Función del Jardín</h3>
              <div className="space-y-2">
                {Object.keys(functions).map((func) => (
                  <Button
                    key={func}
                    onClick={() => setCurrentFunction(func as FunctionType)}
                    variant={currentFunction === func ? "default" : "outline"}
                    className="w-full justify-start"
                    disabled={mode === "guided" && tutorialStep > 0}
                  >
                    {func === "quadratic" && "🌺 Parábola Mágica"}
                    {func === "sine" && "🌊 Onda Senoidal"}
                    {func === "cubic" && "🌿 Curva Cúbica"}
                  </Button>
                ))}
              </div>
            </Card>

            {/* Partitions Control */}
            <Card className="p-4 bg-white/90 backdrop-blur" id="partitions-slider">
              <h3 className="font-semibold mb-3 text-green-800">Número de Macetas</h3>
              <div className="space-y-3">
                <Slider
                  value={partitions}
                  onValueChange={setPartitions}
                  min={2}
                  max={50}
                  step={1}
                  className="w-full"
                  disabled={mode === "guided" && tutorialStep !== 4}
                />
                <div className="text-center text-sm text-green-600">{partitions[0]} macetas</div>
                <div className="text-center">
                  {partitions[0] < 10 && <Badge variant="destructive">Aproximación burda</Badge>}
                  {partitions[0] >= 10 && partitions[0] < 25 && <Badge variant="secondary">Aproximación buena</Badge>}
                  {partitions[0] >= 25 && <Badge className="bg-green-500">Aproximación excelente</Badge>}
                </div>
              </div>
            </Card>

            {/* Limits Control */}
            <Card className="p-4 bg-white/90 backdrop-blur" id="limits">
              <h3 className="font-semibold mb-3 text-green-800">Límites del Jardín</h3>
              <div className="space-y-4">
                <div>
                  <label className="text-sm text-green-600">Límite Izquierdo</label>
                  <Slider
                    value={leftLimit}
                    onValueChange={setLeftLimit}
                    min={-5}
                    max={0}
                    step={0.1}
                    className="w-full"
                    disabled={mode === "guided" && tutorialStep !== 5}
                  />
                  <div className="text-center text-xs text-green-500">a = {leftLimit[0]}</div>
                </div>
                <div>
                  <label className="text-sm text-green-600">Límite Derecho</label>
                  <Slider
                    value={rightLimit}
                    onValueChange={setRightLimit}
                    min={1}
                    max={6}
                    step={0.1}
                    className="w-full"
                    disabled={mode === "guided" && tutorialStep !== 5}
                  />
                  <div className="text-center text-xs text-green-500">b = {rightLimit[0]}</div>
                </div>
              </div>
              {mode === "free" && (
                <div className="mt-3 p-2 bg-yellow-50 rounded-lg border border-yellow-200">
                  <p className="text-yellow-700 text-xs">
                    💡 También puedes arrastrar los puntos rojos y azules directamente en el gráfico
                  </p>
                </div>
              )}
            </Card>

            {/* Approximation Type */}
            <Card className="p-4 bg-white/90 backdrop-blur" id="approximation-type">
              <h3 className="font-semibold mb-3 text-green-800">Tipo de Hechizo</h3>
              <div className="space-y-2">
                {[
                  { key: "left", label: "⬅️ Izquierda", desc: "Altura por la izquierda" },
                  { key: "right", label: "➡️ Derecha", desc: "Altura por la derecha" },
                  { key: "middle", label: "🎯 Centro", desc: "Altura por el centro" },
                ].map((type) => (
                  <Button
                    key={type.key}
                    onClick={() => setApproximationType(type.key as any)}
                    variant={approximationType === type.key ? "default" : "outline"}
                    className="w-full justify-start text-left"
                    disabled={mode === "guided" && tutorialStep > 0}
                  >
                    <div>
                      <div>{type.label}</div>
                      <div className="text-xs opacity-70">{type.desc}</div>
                    </div>
                  </Button>
                ))}
              </div>
            </Card>

            {/* Control Buttons */}
            <Card className="p-4 bg-white/90 backdrop-blur">
              <div className="space-y-2">
                <Button
                  onClick={() => setIsPlaying(!isPlaying)}
                  className="w-full"
                  variant={isPlaying ? "destructive" : "default"}
                >
                  {isPlaying ? <Pause className="w-4 h-4 mr-2" /> : <Play className="w-4 h-4 mr-2" />}
                  {isPlaying ? "Pausar" : "Animar"}
                </Button>
                <Button onClick={handleSimulationReset} variant="outline" className="w-full bg-transparent">
                  <RotateCcw className="w-4 h-4 mr-2" />
                  Reiniciar
                </Button>
                <Button
                  onClick={() => setShowErrorVerification(!showErrorVerification)}
                  variant="outline"
                  className="w-full"
                >
                  🎯 {showErrorVerification ? "Ocultar" : "Mostrar"} Verificación
                </Button>
              </div>
            </Card>
          </div>
        </div>

        {showErrorVerification && mode === "free" && (
          <div className="mt-6 grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-1">
              <ErrorVerification
                riemannSum={calculateRiemannSum()}
                exactIntegral={calculateExactIntegral()}
                error={getError()}
                partitions={partitions[0]}
                onSuccess={handleSimulationSuccess}
                onReset={handleSimulationReset}
                isActive={!simulationCompleted}
              />
            </div>
          </div>
        )}

        {/* Properties Panel - Enhanced with interactive visualizer */}
        {showProperties && (
          <div className="mt-6">
            <PropertiesVisualizer
              functions={functions}
              currentFunction={currentFunction}
              leftLimit={leftLimit[0]}
              rightLimit={rightLimit[0]}
              partitions={partitions[0]}
            />
          </div>
        )}

        {/* Tutorial System */}
        <TutorialSystem
          steps={tutorialSteps}
          currentStep={tutorialStep}
          onStepChange={handleTutorialStepChange}
          onComplete={completeTutorial}
          isVisible={tutorialActive}
          partitions={partitions}
          leftLimit={leftLimit}
          rightLimit={rightLimit}
        />
      </div>
    </div>
  )
}
